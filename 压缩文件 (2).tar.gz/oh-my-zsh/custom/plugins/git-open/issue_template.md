If an incorrect URL is opened, please provide the following so we can write a test:

#### Example clone url:

#### Example branch name:

#### Expected web URL:


