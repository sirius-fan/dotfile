#!/usr/bin/env zsh

autoload -U colors
colors

_fzf_complete_cf7() {
    _fzf_complete_cf "$@"
}
